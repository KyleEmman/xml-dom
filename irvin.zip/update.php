<!doctype html>
<html>
	<head>
		<title>Update Page</title>
	</head>
	<body>
		<form method="post" action="updateProcess.php" enctype="multipart/form-data">
			Student No.: <select name="editId">
				<option>Select ID</option>
				<?php
					$xml = new domdocument("1.0");
					$xml->load("BSIT3GG2G4.xml");
					$scamTypes = $xml->getElementsByTagName("scamType");
					
					foreach($scamTypes as $scamType){
						$id = $scamType->getAttribute("scam");
						echo "<option>" .$id. "</option>";
					}
				?>
			</select><br>
			New Name: <input type="text" name="editName"/><br/>
			New Description: <input type="text" name="editDescription"/><br/>
			New Information: <input type="text" name="editInformation"/><br/>
			New Common Targets: <input type="text" name="editCommonTargets"/><br/>
			New Consequences: <input type="text" name="editConsequences"/><br/>
			New Prevention: <input type="text" name="editPrevention"/><br/>
			New Picture: <input type="file" name="editPicture"/><br/>
			<br/><input type="submit" value="Update">
		</form>
	</body>
</html>