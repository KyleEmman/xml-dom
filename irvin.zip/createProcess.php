<?php
if (!isset($_POST['createScamId'])) {
    header('Location: read.php');
    exit;
}

$xml = new domdocument("1.0");
$xml->formatOutput = true;
$xml->preserveWhiteSpace = false;
$xml->load("BSIT3GG2G4.xml");


$id = $_POST["createScamId"]; 
$name = $_POST["createName"];
$description = $_POST["createDescription"];
$information = $_POST["createInformation"];
$commonTargets = $_POST["createCommonTargets"];
$consequences = $_POST["createConsequences"];
$prevention = $_POST["createPrevention"];

$newScam = $xml->createElement("scamType");  
$newName = $xml->createElement("name", $name); 
$newDescription = $xml->createElement("description", $description);
$newInformation = $xml->createElement("information", $information);
$newCommonTargets = $xml->createElement("commontargets", $commonTargets);
$newConsequences = $xml->createElement("consequences", $consequences);
$newPrevention = $xml->createElement("prevention", $prevention);
$pic = $xml->createElement("picture"); 
$imageData = file_get_contents($_FILES["createPicture"]["tmp_name"]);
$base64 = base64_encode($imageData);
$cdata = $xml->createCDATASection($base64);
$pic->appendChild($cdata);

$newScam->appendChild($newName);
$newScam->appendChild($newDescription);
$newScam->appendChild($newInformation);
$newScam->appendChild($newCommonTargets);
$newScam->appendChild($newConsequences);
$newScam->appendChild($newPrevention);
$newScam->appendChild($pic);
$newScam->setAttribute("scam", $id);

$xml->getElementsByTagName("scamTypes")->item(0)->appendchild($newScam); 
$xml->save("BSIT3GG2G4.xml");
echo "
<script>
    alert('Record saved!')
    window.location.href = 'read.php'
</script>
";
?>