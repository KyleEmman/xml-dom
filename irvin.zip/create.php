<!doctype html>
<html>
	<head>
		<title>Create Page</title>
        <style>
            form {
                display: flex;
                flex-direction: column;
                gap: 2px;
                width: 500px;
            }
        </style>
	</head>
	<body>
        <form method="post" action="createProcess.php" enctype="multipart/form-data">
            <label for="createScamId">Id:</label>
            <input type="text" id="createScamId" name="createScamId" required>
            <label for="createName">Name:</label>
            <input type="text" id="createName" name="createName" required>
            <label for="createDescription">Description:</label>
            <input type="text" id="createDescription" name="createDescription" required>
            <label for="createInformation">Information:</label>
            <input type="text" id="createInformation" name="createInformation" required>
            <label for="createCommonTargets">Common Targets:</label>
            <input type="text" id="createCommonTargets" name="createCommonTargets" required>
            <label for="createConsequences">Consequences:</label>
            <input type="text" id="createConsequences" name="createConsequences" required>
            <label for="createPrevention">Prevention:</label>
            <input type="text" id="createPrevention" name="createPrevention" required>
            <label for="createPicture">Picture:</label>
            <input type="file" name="createPicture" id="createPicture" required>
            <input type="submit" value="Save">
        </form>
	</body>
</html>